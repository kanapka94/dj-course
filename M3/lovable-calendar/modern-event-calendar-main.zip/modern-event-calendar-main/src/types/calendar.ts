export interface CalendarEvent {
  id: string;
  title: string;
  date: Date;
  description?: string;
  color: 'primary' | 'secondary' | 'success' | 'warning';
  startTime?: string;
  endTime?: string;
}
