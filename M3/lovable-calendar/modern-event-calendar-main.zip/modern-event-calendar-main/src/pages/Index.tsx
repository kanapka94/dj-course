import { useState } from 'react';
import { CalendarGrid } from '@/components/Calendar/CalendarGrid';
import { CalendarEvent } from '@/types/calendar';
import { mockEvents } from '@/data/mockEvents';
import { Calendar } from 'lucide-react';

const Index = () => {
  const [events, setEvents] = useState<CalendarEvent[]>(mockEvents);

  const handleUpdateEvent = (updatedEvent: CalendarEvent) => {
    setEvents((prevEvents) => {
      const existingEvent = prevEvents.find(e => e.id === updatedEvent.id);
      if (existingEvent) {
        // Update existing event
        return prevEvents.map((event) =>
          event.id === updatedEvent.id ? updatedEvent : event
        );
      } else {
        // Add new event
        return [...prevEvents, updatedEvent];
      }
    });
  };

  const handleDeleteEvent = (eventId: string) => {
    setEvents((prevEvents) => prevEvents.filter((event) => event.id !== eventId));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Calendar className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                My Calendar
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your events and schedule
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-6 sm:py-8">
        <CalendarGrid 
          events={events} 
          onUpdateEvent={handleUpdateEvent}
          onDeleteEvent={handleDeleteEvent}
        />
      </main>
    </div>
  );
};

export default Index;
