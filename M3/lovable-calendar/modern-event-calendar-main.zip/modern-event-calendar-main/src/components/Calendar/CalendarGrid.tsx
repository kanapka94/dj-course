import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CalendarEvent } from '@/types/calendar';
import { EventModal } from './EventModal';
import { cn } from '@/lib/utils';

interface CalendarGridProps {
  events: CalendarEvent[];
  onUpdateEvent: (event: CalendarEvent) => void;
  onDeleteEvent: (eventId: string) => void;
}

export const CalendarGrid = ({ events, onUpdateEvent, onDeleteEvent }: CalendarGridProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    return { daysInMonth, startingDayOfWeek };
  };

  const { daysInMonth, startingDayOfWeek } = getDaysInMonth(currentDate);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleEventClick = (event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedEvent(event);
    setSelectedDate(undefined);
    setIsModalOpen(true);
  };

  const handleDayClick = (day: number, e: React.MouseEvent) => {
    // Only open create dialog if clicking on empty space (not an event)
    const target = e.target as HTMLElement;
    if (target.tagName === 'BUTTON') return; // Don't trigger if clicking event button
    
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedEvent(null);
    setSelectedDate(newDate);
    setIsModalOpen(true);
  };

  const handleAddEventClick = (day: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedEvent(null);
    setSelectedDate(newDate);
    setIsModalOpen(true);
  };

  const getEventsForDay = (day: number) => {
    return events.filter((event) => {
      const eventDate = new Date(event.date);
      return (
        eventDate.getDate() === day &&
        eventDate.getMonth() === currentDate.getMonth() &&
        eventDate.getFullYear() === currentDate.getFullYear()
      );
    });
  };

  const isToday = (day: number) => {
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    );
  };

  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const renderCalendarDays = () => {
    const days = [];
    
    // Empty cells for days before month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(
        <div key={`empty-${i}`} className="min-h-[100px] sm:min-h-[120px] bg-muted/30 rounded-lg" />
      );
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayEvents = getEventsForDay(day);
      const isTodayDate = isToday(day);

      days.push(
        <Card
          key={day}
          onClick={(e) => handleDayClick(day, e)}
          className={cn(
            'min-h-[100px] sm:min-h-[120px] p-2 sm:p-3 transition-all hover:shadow-md cursor-pointer group relative',
            isTodayDate && 'ring-2 ring-calendar-today bg-primary/5'
          )}
        >
          <div className="flex flex-col h-full">
            <div
              className={cn(
                'text-sm sm:text-base font-medium mb-2 flex items-center justify-between',
                isTodayDate
                  ? 'text-primary font-bold'
                  : 'text-foreground'
              )}
            >
              <div>
                {day}
                {isTodayDate && (
                  <span className="ml-2 text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                    Today
                  </span>
                )}
              </div>
              <button
                onClick={(e) => handleAddEventClick(day, e)}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-primary/10 rounded"
                aria-label="Add event"
              >
                <Plus className="h-4 w-4 text-primary" />
              </button>
            </div>
            <div className="flex-1 space-y-1 overflow-y-auto">
              {dayEvents.map((event) => (
                <button
                  key={event.id}
                  onClick={(e) => handleEventClick(event, e)}
                  className={cn(
                    'w-full text-left px-2 py-1 rounded text-xs sm:text-sm truncate transition-all hover:scale-105',
                    event.color === 'primary' && 'bg-calendar-event-primary/20 text-calendar-event-primary hover:bg-calendar-event-primary/30',
                    event.color === 'secondary' && 'bg-calendar-event-secondary/20 text-calendar-event-secondary hover:bg-calendar-event-secondary/30',
                    event.color === 'success' && 'bg-calendar-event-success/20 text-calendar-event-success hover:bg-calendar-event-success/30',
                    event.color === 'warning' && 'bg-calendar-event-warning/20 text-calendar-event-warning hover:bg-calendar-event-warning/30'
                  )}
                >
                  {event.startTime && <span className="font-medium">{event.startTime} </span>}
                  {event.title}
                </button>
              ))}
            </div>
          </div>
        </Card>
      );
    }

    return days;
  };

  return (
    <div className="w-full max-w-7xl mx-auto p-4 sm:p-6">
      <Card className="p-4 sm:p-6 shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground">{monthName}</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handlePrevMonth}
              className="hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={handleNextMonth}
              className="hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Week days header */}
        <div className="grid grid-cols-7 gap-2 mb-3">
          {weekDays.map((day) => (
            <div
              key={day}
              className="text-center text-xs sm:text-sm font-semibold text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-2">
          {renderCalendarDays()}
        </div>
      </Card>

      {/* Event Modal */}
      <EventModal
        event={selectedEvent}
        selectedDate={selectedDate}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedEvent(null);
          setSelectedDate(undefined);
        }}
        onSave={onUpdateEvent}
        onDelete={onDeleteEvent}
      />
    </div>
  );
};
